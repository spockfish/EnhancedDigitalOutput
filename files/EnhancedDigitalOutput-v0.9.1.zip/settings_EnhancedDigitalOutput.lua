settings = {autoKernelUpdate=false,firstUse=false,periodCount=4,embeddedTTHack=false,cpuIdleFullspeed=false,bufferTime=100000,playbackDevice="TXRX",}
